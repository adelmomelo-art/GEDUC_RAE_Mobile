import 'package:flutter/material.dart';
import '../../../core/services/tipo_acao_service.dart';
import '../../../data/models/tipo_acao_model.dart';

class TipoAcaoController extends ChangeNotifier {
  final TipoAcaoService service;
  TipoAcaoController({required this.service});
  List<TipoAcaoModel> tipos = [];
  bool carregando = false;
  Future<void> carregarTipos() async { carregando = true; notifyListeners(); tipos = await service.listarTiposAcoes(); carregando = false; notifyListeners(); }
}
