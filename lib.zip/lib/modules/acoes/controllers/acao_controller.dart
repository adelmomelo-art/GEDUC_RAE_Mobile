import 'dart:async';

import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../../../core/services/acao_rules_service.dart';
import '../../../core/services/firebase_acao_service.dart';
import '../../../core/services/offline_service.dart';
import '../../../core/services/sync_service.dart';
import '../../../data/models/acao_model.dart';

class AcaoController extends ChangeNotifier {
  final OfflineService offlineService;
  final FirebaseAcaoService firebaseService;
  final SyncService syncService;

  AcaoController({
    required this.offlineService,
    required this.firebaseService,
    required this.syncService,
  });

  AcaoModel? acaoAtual;
  String? erro;
  bool gerandoNumeroRae = false;
  bool carregandoRascunho = false;

  Future<void> carregarRascunhoOuCriarNovo() async {
    carregandoRascunho = true;
    notifyListeners();

    final rascunho = await offlineService.recuperarRascunhoAcao();

    if (rascunho != null) {
      acaoAtual = rascunho;
    } else {
      criarRascunhoInicial();
    }

    carregandoRascunho = false;
    notifyListeners();
  }

  void criarRascunhoInicial() {
    final agora = DateTime.now();

    acaoAtual = AcaoModel(
      id: const Uuid().v4(),
      numeroRAE: '',
      anoRAE: agora.year,
      dataAcao: agora,
      turno: '',
      horaInicio: '${agora.hour}:${agora.minute}',
      nomeAcao: '',
      tipoAcao: '',
      publicoEstimado: 0,
      publicoMinimo: 0,
      pessoasAlcancadas: 0,
      veiculosAbordados: 0,
      credenciaisEmitidas: 0,
      metaAtingida: false,
      endereco: '',
      bairro: '',
      regional: '',
      latitude: 0,
      longitude: 0,
      coordenadorId: '',
      coordenadorNome: '',
      fotosUrls: const [],
      descricaoEvidencias: '',
      status: 'rascunho',
      sincronizado: false,
    );

    unawaited(_salvarRascunhoAtual());
    notifyListeners();
  }

  Future<void> _salvarRascunhoAtual() async {
    final acao = acaoAtual;

    if (acao == null) {
      return;
    }

    await offlineService.salvarRascunhoAcao(acao);
  }

  Future<void> garantirNumeroRae() async {
    if (acaoAtual == null) {
      criarRascunhoInicial();
    }

    if (acaoAtual!.numeroRAE.isNotEmpty) {
      return;
    }

    gerandoNumeroRae = true;
    notifyListeners();

    try {
      final numero = await firebaseService.gerarNumeroRaeAutomatico();
      final ano = DateTime.now().year;

      acaoAtual = acaoAtual!.copyWith(
        numeroRAE: numero,
        anoRAE: ano,
      );

      await _salvarRascunhoAtual();
    } finally {
      gerandoNumeroRae = false;
      notifyListeners();
    }
  }

  void preencherDadosAcao({
    required String turno,
    required String nomeAcao,
    required String tipoAcao,
    required int publicoEstimado,
    required int publicoMinimo,
    String? coordenadorId,
    String? coordenadorNome,
  }) {
    if (acaoAtual == null) criarRascunhoInicial();

    acaoAtual = acaoAtual!.copyWith(
      turno: turno,
      nomeAcao: nomeAcao,
      tipoAcao: tipoAcao,
      publicoEstimado: publicoEstimado,
      publicoMinimo: publicoMinimo,
      coordenadorId: coordenadorId,
      coordenadorNome: coordenadorNome,
    );

    unawaited(_salvarRascunhoAtual());
    notifyListeners();
  }

  void preencherLocalizacao({
    required String endereco,
    required String bairro,
    required String regional,
    required double latitude,
    required double longitude,
  }) {
    if (acaoAtual == null) criarRascunhoInicial();

    acaoAtual = acaoAtual!.copyWith(
      endereco: endereco,
      bairro: bairro,
      regional: regional,
      latitude: latitude,
      longitude: longitude,
    );

    unawaited(_salvarRascunhoAtual());
    notifyListeners();
  }

  void preencherResultados({
    required int pessoasAlcancadas,
    required int veiculosAbordados,
    required int credenciaisEmitidas,
    String? motivoMetaNaoAtingida,
  }) {
    if (acaoAtual == null) criarRascunhoInicial();

    final meta = AcaoRulesService.calcularMeta(
      pessoasAlcancadas: pessoasAlcancadas,
      publicoMinimo: acaoAtual!.publicoMinimo,
    );

    final agora = DateTime.now();

    acaoAtual = acaoAtual!.copyWith(
      pessoasAlcancadas: pessoasAlcancadas,
      veiculosAbordados: veiculosAbordados,
      credenciaisEmitidas: credenciaisEmitidas,
      metaAtingida: meta,
      motivoMetaNaoAtingida: motivoMetaNaoAtingida,
      horaFinal: '${agora.hour}:${agora.minute}',
    );

    unawaited(_salvarRascunhoAtual());
    notifyListeners();
  }

  void preencherEvidencias({
    required List<String> fotosUrls,
    required String descricaoEvidencias,
  }) {
    if (acaoAtual == null) criarRascunhoInicial();

    acaoAtual = acaoAtual!.copyWith(
      fotosUrls: fotosUrls,
      descricaoEvidencias: descricaoEvidencias,
    );

    unawaited(_salvarRascunhoAtual());
    notifyListeners();
  }

  bool validarAntesDoEnvio() {
    erro = null;
    final acao = acaoAtual;

    if (acao == null) {
      erro = 'Nenhuma ação foi criada.';
      return false;
    }

    if (acao.turno.isEmpty) {
      erro = 'Informe o turno.';
      return false;
    }

    if (acao.nomeAcao.isEmpty) {
      erro = 'Informe o nome da ação.';
      return false;
    }

    if (acao.endereco.isEmpty && acao.latitude == 0) {
      erro = 'Informe a localização.';
      return false;
    }

    if (acao.pessoasAlcancadas <= 0) {
      erro = 'Informe as pessoas alcançadas.';
      return false;
    }

    if (AcaoRulesService.motivoMetaObrigatorio(
      metaAtingida: acao.metaAtingida,
      motivo: acao.motivoMetaNaoAtingida,
    )) {
      erro = 'Informe o motivo da meta não atingida.';
      return false;
    }

    return true;
  }

  Future<bool> enviarRelatorio() async {
    if (!validarAntesDoEnvio()) {
      notifyListeners();
      return false;
    }

    await garantirNumeroRae();

    if (await syncService.temInternet()) {
      await firebaseService.salvarAcao(acaoAtual!);
    } else {
      await offlineService.salvarAcaoPendente(acaoAtual!);
    }

    acaoAtual = acaoAtual!.copyWith(
      status: 'enviado',
      sincronizado: true,
    );

    await offlineService.excluirRascunhoAcao();

    notifyListeners();
    return true;
  }
}