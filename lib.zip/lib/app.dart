import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/routes/app_routes.dart';
import 'core/services/firebase_acao_service.dart';
import 'core/services/offline_service.dart';
import 'core/services/sync_service.dart';
import 'core/services/usuario_service.dart';
import 'core/services/tipo_acao_service.dart';
import 'core/theme/app_theme.dart';
import 'modules/acoes/controllers/acao_controller.dart';
import 'modules/admin/controllers/tipo_acao_controller.dart';
import 'modules/admin/controllers/usuario_controller.dart';

class GeducRaeApp extends StatelessWidget {
  const GeducRaeApp({super.key});

  @override
  Widget build(BuildContext context) {
    final offlineService = OfflineService();
    final firebaseService = FirebaseAcaoService();
    final usuarioService = UsuarioService();
    final tipoAcaoService = TipoAcaoService();

    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => AcaoController(
            offlineService: offlineService,
            firebaseService: firebaseService,
            syncService: SyncService(
              offlineService: offlineService,
              firebaseService: firebaseService,
            ),
          ),
        ),
        ChangeNotifierProvider(
          create: (_) => UsuarioController(usuarioService: usuarioService),
        ),
        ChangeNotifierProvider(
          create: (_) => TipoAcaoController(service: tipoAcaoService),
        ),
      ],
      child: MaterialApp.router(
        title: 'GEDUC RAE Mobile',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        routerConfig: AppRoutes.router,
      ),
    );
  }
}
