import 'package:flutter/material.dart';
import '../../../core/services/usuario_service.dart';
import '../../../data/models/usuario_model.dart';

class UsuarioController extends ChangeNotifier {
  final UsuarioService usuarioService;
  UsuarioController({required this.usuarioService});
  List<UsuarioModel> usuarios=[];
  bool carregando=false;
  Future<void> carregarUsuarios() async { carregando=true; notifyListeners(); usuarios = await usuarioService.listarUsuarios(); carregando=false; notifyListeners(); }
}
